AFG11000 Software Readme File                                   

The software system for the AFG11000 consists of two things:

1) USB drivers for FTDI chipset (usually installed automatically on Win7).

2) AFG11000 card API  (e.g. afg11000.exe and ftd2xx.dll). See respective 
   directories.

See AFG11000_Manual.pdf for complete details on software installation, the GUI 
application, and programmers API.


-------------------------------------------------------------------------------


In general, the USB system drivers should automatically install on Windows 7 if 
automatic updates is enabled. If not, then you can follow the procedure below. 
See directory called "USB_Driver_Installation_Guide" for details on Win7 and 
other operating systems.


Installing the latest drivers:
------------------------------
Do not connect your USB-serial converter to the PC USB port yet.
Download the exe file from the link below to your PC.
http://www.ftdichip.com/Drivers/CDM/CDM20824_Setup.exe

Right-click on the CDM20824_Setup.exe file and select �Run as Administrator� 
to ensure that the program is run with administrator privileges.

A command window will appear (see Figure 5 below). A row of dots indicates 
progress, and a success message will appear in the command window. It will 
close after a few seconds.

It is recommended to run the installer a second time by right-clicking on 
CDM20824_Setup.exe and selecting �Run as Administrator�. Occasionally, Windows 
runs the processes in the installer in a slightly different order and this can 
result in a file not being copied over. Running the installer a second time 
ensures that all files were copied.